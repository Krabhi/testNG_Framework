package Test;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import base.baseTest;
import pageEvents.homePageEvent;
import pageEvents.loginPageEvent;
import utils.elementFetch;
import pageObjects.loginPageElements;
import pageObjects.homePageElements;

public class testCase1 extends baseTest {


	elementFetch elem = new elementFetch();
	homePageEvent homeEvent = new homePageEvent();
	loginPageEvent loginEvent = new loginPageEvent();

	@Test


	public void sampleMethodforCred() throws InterruptedException {
		//  driver.wait(10000);
		logger.info("click on login button and navigate to signin page");
		homeEvent.redirect2login();
		logger.info("validate signin page");
		loginEvent.loginPageLoaded();
		logger.info("login with valid data");
		loginEvent.loginByValidData();


	}
}
