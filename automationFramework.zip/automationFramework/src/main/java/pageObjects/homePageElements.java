package pageObjects;

public interface homePageElements {
	
	
	String buttonforloginpage = "//span[normalize-space()='Log In']";
	
	

}
