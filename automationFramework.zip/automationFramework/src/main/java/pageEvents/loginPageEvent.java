package pageEvents;


import org.testng.Assert;

import pageObjects.loginPageElements;
import utils.elementFetch;

public class loginPageEvent {
	elementFetch elem = new elementFetch();

	public void loginPageLoaded() {
		
		Assert.assertTrue(elem.getWebElement("XPATH", loginPageElements.loginBtn).isDisplayed());
		
	}
	
	

	public void loginByValidData() {
		
		elem.getWebElement("XPATH", loginPageElements.emailField).sendKeys("abhishek@gmail.com");
		elem.getWebElement("XPATH", loginPageElements.passwordFiled).sendKeys("qwerty@123");
		elem.getWebElement("XPATH", loginPageElements.loginBtn).click();
	}



}
