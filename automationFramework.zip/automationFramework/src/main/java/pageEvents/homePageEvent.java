package pageEvents;

import pageObjects.homePageElements;
import utils.elementFetch;

public class homePageEvent {
	
	elementFetch elem = new elementFetch();
	
	public void redirect2login() {
		
		elem.getWebElement("XPATH", homePageElements.buttonforloginpage).click();
		

		
	}


}
