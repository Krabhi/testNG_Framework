package utils;

public interface constants {
	
	String URL = "https://freecrm.com/";
	

}
